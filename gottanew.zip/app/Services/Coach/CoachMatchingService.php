<?php

namespace App\Services\Coach;

use App\Models\Coach\Coach;

class CoachMatchingService
{

    public function match($goalId, $responses, $personality = null)
    {

        $coaches = Coach::where('is_active', true)->get();

        $results = [];

        foreach ($coaches as $coach) {

            $score = 0;

            /*
            |--------------------------------------------------
            | Goal Match
            |--------------------------------------------------
            */

            if (str_contains(
                strtolower($coach->coaching_expertise),
                strtolower($goalId)
            )) {
                $score += 50;
            }

            /*
            |--------------------------------------------------
            | Response Keyword Match
            |--------------------------------------------------
            */

            foreach ($responses as $response) {

                if (!isset($response['answer'])) continue;

                if (str_contains(
                    strtolower($coach->specialties),
                    strtolower($response['answer'])
                )) {
                    $score += 20;
                }

            }

            /*
            |--------------------------------------------------
            | Personality Compatibility
            |--------------------------------------------------
            */

            if ($personality) {

                $personalityString = json_encode($personality);

                if (str_contains(
                    strtolower($coach->coaching_style ?? ''),
                    strtolower($personalityString)
                )) {
                    $score += 15;
                }

            }

            /*
            |--------------------------------------------------
            | Rating Boost
            |--------------------------------------------------
            */

            $score += ($coach->rating ?? 0) * 2;

            $results[] = [
                'coachId' => $coach->id,
                'coachName' => $coach->name,
                'confidenceScore' => $score,
                'matchReason' => "Strong alignment with your goals and responses.",
                'coach' => $coach
            ];

        }

        /*
        |--------------------------------------------------
        | Sort Best Coaches
        |--------------------------------------------------
        */

        usort($results, fn($a, $b) => $b['confidenceScore'] <=> $a['confidenceScore']);

        return array_slice($results, 0, 8);

    }
}